package com.example.ecotrip5.DinaResor;

public class Resa {
    private String title;

    public Resa(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}

